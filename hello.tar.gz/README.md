based on: <a href="https://beego.me">beego</a> <br>
created by: <a href="https://github.com/mad3hat">madhat</a>
